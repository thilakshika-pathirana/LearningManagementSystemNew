package lerning.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project1 extends JFrame implements ActionListener {

    Project1() {
        setSize(1540, 850);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/first.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1500, 750, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        add(image);
        
        JMenuBar mb = new JMenuBar();
        
        // New Information
        JMenu LogIn = new JMenu("Log In");
        LogIn.setForeground(Color.BLUE);
        mb.add(LogIn);
        
        JMenuItem AdminInfo = new JMenuItem("Admin");
        AdminInfo.setBackground(Color.WHITE);
        AdminInfo.addActionListener(this);
        LogIn.add(AdminInfo);
        
        JMenuItem TeacherInfo = new JMenuItem("Teacher");
        TeacherInfo.setBackground(Color.WHITE);
        TeacherInfo.addActionListener(this);
        LogIn.add(TeacherInfo);
        
        JMenuItem studentInfo = new JMenuItem("Student");
        studentInfo.setBackground(Color.WHITE);
        studentInfo.addActionListener(this);
        LogIn.add(studentInfo);
        
        
        // Details
        JMenu details = new JMenu("View Details");
        details.setForeground(Color.RED);
        mb.add(details);
        
        
        
       
        // Exams
        JMenu exam = new JMenu("Examination");
        exam.setForeground(Color.BLUE);
        mb.add(exam);
        
        
        
       
        
        // fee
        JMenu fee = new JMenu("Fee Details");
        fee.setForeground(Color.BLUE);
        mb.add(fee);
        
       
     
        JMenu utility = new JMenu("Utility");
        utility.setForeground(Color.RED);
        mb.add(utility);
        
        JMenuItem notepad = new JMenuItem("Notepad");
        notepad.setBackground(Color.WHITE);
        notepad.addActionListener(this);
        utility.add(notepad);
        
        JMenuItem calc = new JMenuItem("Calculator");
        calc.setBackground(Color.WHITE);
        calc.addActionListener(this);
        utility.add(calc);
        
        
        JMenu about = new JMenu("About");
        about.setForeground(Color.BLUE);
        mb.add(about);
        
        JMenuItem ab = new JMenuItem("About");
        ab.setBackground(Color.WHITE);
        ab.addActionListener(this);
        about.add(ab);
        
        // exit
        JMenu exit = new JMenu("Exit");
        exit.setForeground(Color.RED);
        mb.add(exit);
        
        JMenuItem ex = new JMenuItem("Exit");
        ex.setBackground(Color.WHITE);
        ex.addActionListener(this);
        exit.add(ex);
        
        setJMenuBar(mb);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        String msg = ae.getActionCommand();
        
        if (msg.equals("Exit")) {
            setVisible(false);
        } else if (msg.equals("Calculator")) {
            try {
                Runtime.getRuntime().exec("calc.exe");
            } catch (Exception e) {
                
            }
        } else if (msg.equals("Notepad")) {
            try {
                Runtime.getRuntime().exec("notepad.exe");
            } catch (Exception e) {
                
            }
        } else if (msg.equals("Admin")) {
            setVisible(false);
            new Login();
        } else if (msg.equals("Teacher")) {
            
        } else if (msg.equals("Student")) {
            
        
        } else if (msg.equals("About")) {
            new About();
       
        }
    }

    public static void main(String[] args) {
        new Project1();
    }
}
